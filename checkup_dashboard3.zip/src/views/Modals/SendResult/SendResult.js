import React from 'react';

import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';
import 'react-awesome-slider/dist/styles.css';
import InputLabel from "@material-ui/core/InputLabel";
// core components
import GridItem from "components/Grid/GridItem.js";
import GridContainer from "components/Grid/GridContainer.js";
import CustomInput from "components/CustomInput/CustomInput.js";
import database from '../../../firebase';
import ResultFiles from './ResultFiles'
import firebase from 'firebase';
import SendResultConfirmationAlert from './SendResultConfirmationAlert';

const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />;
});

export default class SendResult extends React.Component {
    constructor(){
        super()
        var uploadedFiles = [];
    }
        state = {
            open: false,
            resultFilespaths : [],
            // Employee: {
            //     name: '',
            //     address: ''

            // }
            // Employee: []
            // Employee: {
            //     userName: '',
            //     email: '',
            //     password: '',
            //     imagePath: '',
            //     phones: ['']
            // },
            test:{
                date: '',
                description: '',
                id: '',
                isFromHome: false,
                resultFilespaths: [],
                roushettaPath: [],
                status: '',
                testName: '',
                time: '',
                userId: '',
                description: ''
            }

        }
    
    componentDidMount() {
        debugger

        this.getUserData();

    }
    getUserData = () => {
        debugger;
        // database.ref('/').child('Tests').child('0G9djW7SzMXGTiXKdGkiYuiTY3g1').child(this.props.testId).set(this.state.test);

        let ref = database.ref('/').child('Tests').child('0G9djW7SzMXGTiXKdGkiYuiTY3g1').child(this.props.testId);
        ref.on('value', snapshot => {
            debugger
            var testObj = snapshot.val();
            console.log(testObj)
            this.setState({test: testObj});
        });
        console.log('DATA RETRIEVED');
    }
    deleteFile = (index) =>{
        this.state.test.resultFilespaths.splice(index,1);
        this.uploadedFiles.splice(index,1);
        this.forceUpdate()
    }
    onImageChange = (event) => {
        debugger
        if (event.target.files) {
            // this.uploadedFiles = event.target.files;
            this.state.test.resultFilespaths = []
            this.uploadedFiles = []
            for (let i = 0; i < event.target.files.length; i++) {
                this.uploadedFiles.push(event.target.files[i])
                this.state.test.resultFilespaths.push('/TestResults/'+ this.props.testId + '/'+ event.target.files[i].name) ;
            }
            // this.state.test.resultFilespaths = this.state.resultFilespaths;
            this.forceUpdate();
            // this.setState({
            //     Employee: {
            //         ...this.state.Employee,
            //         imagePath: '/images/' + event.target.files[0].name
            //     }
            // })
            // let reader = new FileReader();
            // reader.onload = (e) => {
            //     this.setState({ image: e.target.result });

            // };
            // reader.readAsDataURL(event.target.files[0]);
        }
    }
    
    handleClose = () => {
        this.setState({ open: false })
    }
    handleConfirm = () => {
        this.updateData();
        this.setState({ open: false })
    }
    handleOpenAlert = ()=> {
        debugger
        this.setState({open: true})
        
    }
    updateData = () =>{
        debugger
        var storageRef = firebase.storage().ref('/TestResults/' + this.props.testId + '/');
                
        // var metadata = {
        //     contentType: 'image/jpeg',
        //   };

            // Upload the file and metadata
        for (let i = 0; i < this.uploadedFiles.length; i++) {
            var uploadTask = storageRef.child(this.uploadedFiles[i].name).put(this.uploadedFiles[i]);
        }
        this.state.test.status = 'Done'
        database.ref('/').child('Tests').child('0G9djW7SzMXGTiXKdGkiYuiTY3g1').child(this.props.testId).set(this.state.test);
        this.props.handleClose();
    }

    // const classes = useStyles();
render(){
    
    const styleTestReview = {
        appBar: {
            position: 'relative',
        },
        title: {
            // marginLeft: theme.spacing(2),
            flex: 1,
        },
        TestDataObject: {
            display: 'inline-block',
            alignItems: 'flex-end'
        },
        TestData: {
            display: 'inline-block',
            width: '50%'
        },
        ImgTestPic: {
            width: '100%'
        },
        TestDataObject: {
            display: 'inline-block',
            alignItems: 'flex-end'
        },
        TestPic: {
            display: 'inline-block',
            verticalAlign: 'top',
            alignSelf: 'flex-end',
            width: '50%'
        },
        btnAction:{
            margin: '0 auto',
            width: '150px',
            marginLeft: '80px'
        },
        refuseBtn: {
            width: '150px',
            color : '#ff0000'
        }
        // TestReviewModal:{
        //     height: "100%",
        //     // backgroundColor: "blueviolet",
        //     width: "100%",
        // }
    }
    
    return (
        <div>
            {this.state.open?<SendResultConfirmationAlert open={this.state.open} handleConfirm={this.handleConfirm.bind(this)}  handleClose={this.handleClose.bind(this)}></SendResultConfirmationAlert>:''}
            <Dialog fullScreen open={this.props.open} onClose={this.props.handleClose} TransitionComponent={Transition}>
                <AppBar style={styleTestReview.appBar}>
                    <Toolbar>
                        <IconButton edge="start" color="inherit" onClick={this.props.handleClose} aria-label="close">
                            <CloseIcon />
                        </IconButton>
                        <Typography variant="h6" style={styleTestReview.title}>
                            Test Review

                            
            </Typography>
            
            <Button autoFocus style={styleTestReview.btnAction} color="inherit" 
                onClick={this.handleOpenAlert.bind(this)}>
                        Accept
            </Button>
                    </Toolbar>
                </AppBar>
                <div style={styleTestReview.TestReviewModal}>
                    <div style={styleTestReview.TestData}>
                        <br></br>

                    <GridContainer>
                        <GridItem xs={12} sm={12} md={12}>
                        <InputLabel style={{ color: "#AAAAAA" }}>Some Info About Result</InputLabel>
                        <CustomInput
                            labelText="Enter Description About Test Result For User"
                            id="about-me"
                            formControlProps={{
                            fullWidth: true
                            }}
                            value={this.state.test.description}
                            onChange={ e => {
                                debugger
                                this.setState({
                                    
                                    test: {
                                        ...this.state.test,
                                        description: e.target.value
                                    }
                                })
                            }}
                            inputProps={{
                            multiline: true,
                            rows: 5
                            }}
                        />
                        </GridItem>
                    </GridContainer>
                    <div>
                        <input onChange={this.onImageChange.bind(this)} accept="application/pdf,application/vnd.ms-excel,image/*" id="icon-button-file" type="file" multiple/>
                                        
                                    </div>
                    {this.state.test.resultFilespaths? this.state.test.resultFilespaths.map((textValue,index)=> (
                                            
                        <ResultFiles key={index} index={index} count={this.state.test.resultFilespaths.length} textValue={textValue} deleteFile={this.deleteFile} changeText={this.changeText}></ResultFiles>
                    )): ''}
                    </div>
                    <div style={styleTestReview.TestPic}>
                        
                    </div>
                </div>
            </Dialog>
        </div>
    );
                
}
}
// import React from 'react';
// import { Button, Modal } from 'react-bootstrap';
// import CustomInput from "components/CustomInput/CustomInput.js";

// export default class RefusedRequest extends React.Component {
//     state = {
//         show: true
//     }

//     mystyle = {

//     };

//     render() {
//         return (
//             <div>
//                 <Modal
//                     dialogClassName="TestReviewModal MyBody AllBtns AcceptBtn"
//                     show={this.state.show}
//                     size="xl"
//                     aria-labelledby="contained-modal-title-vcenter"
//                     centered
//                 >
//                     <Modal.Header closeButton={false}>
//                         <Modal.Title id="contained-modal-title-vcenter">
//                             Refused Request
//                         </Modal.Title>
//                     </Modal.Header>
//                     <Modal.Body>
//                         <input type="checkbox" name="" value="" />
//                         <span> Not Available</span>
//                         <br></br>
//                         <input type="checkbox" name="" value="" />
//                         <span> Another Time</span>
//                         <br></br>
//                         <input type="checkbox" name="" value="" />
//                         <span> you need to apply precaustion </span>
//                         <br></br>
//                         <br></br>
//                         <p>Refuse Reson : </p>
//                         <textarea id="w3mission" rows="4" cols="50"></textarea>
//                         <div>
//                             <label for="refuse">Choose Employee</label>

//                             <select id="refuse">
//                                 <option value="Ali">Ali</option>
//                                 <option value="Muhamed">Muhamed</option>
//                                 <option value="sara">sara</option>
//                                 <option value="alia">alia</option>
//                             </select>
//                         </div>
//                     </Modal.Body>
//                     <Modal.Footer>
//                         <Button>Done</Button>
//                     </Modal.Footer>
//                 </Modal>
//             </div>
//         );
//     }
// }

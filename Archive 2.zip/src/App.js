import React from 'react';
import logo from './logo.svg';
import './App.css';
import Admin from './layouts/Admin';
function App() {
  return (
    <div className="App">
      <Admin></Admin>
    </div>
  );
}

export default App;

import React from 'react';
import CheckLogin from './CheckLogin'

export default function EntryPoint() {
    
    return (
        <CheckLogin></CheckLogin>
    );
}
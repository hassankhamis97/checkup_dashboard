import React from "react";
import UpCommingRequests from "../UpCommingRequests/UpCommingRequests.js";


export default function Dashboard() {


  return (
    <UpCommingRequests>
       
    </UpCommingRequests>
  );
}
